"""Nand2Tetris Project 6: translate Hack assembly into machine code.

Usage: python Assembler.py path/to/Program.asm
Output: path/to/Program.hack (overwrites an existing output file).
Requires Python 3; no additional packages needed.
"""

import argparse
import re
from pathlib import Path


# C-instruction layout: 111 + comp (7 bits) + dest (3) + jump (3).
COMP = {
    "0": "0101010", "1": "0111111", "-1": "0111010",
    "D": "0001100", "A": "0110000", "M": "1110000",
    "!D": "0001101", "!A": "0110001", "!M": "1110001",
    "-D": "0001111", "-A": "0110011", "-M": "1110011",
    "D+1": "0011111", "A+1": "0110111", "M+1": "1110111",
    "D-1": "0001110", "A-1": "0110010", "M-1": "1110010",
    "D+A": "0000010", "D+M": "1000010",
    "D-A": "0010011", "D-M": "1010011",
    "A-D": "0000111", "M-D": "1000111",
    "D&A": "0000000", "D&M": "1000000",
    "D|A": "0010101", "D|M": "1010101",
}

DEST = {
    "": "000", "M": "001", "D": "010", "MD": "011",
    "A": "100", "AM": "101", "AD": "110", "AMD": "111",
    # Accept both spellings explicitly required by the Project 6 handout.
    "DM": "011", "ADM": "111",
}

JUMP = {
    "": "000", "JGT": "001", "JEQ": "010", "JGE": "011",
    "JLT": "100", "JNE": "101", "JLE": "110", "JMP": "111",
}


def valid_symbol(name):
    """Symbols cannot start with a digit; Hack symbols are case-sensitive."""
    return re.fullmatch(r"[A-Za-z_.$:][A-Za-z0-9_.$:]*", name) is not None


def clean_lines(source):
    """Remove // comments, whitespace, and blank lines; keep line numbers."""
    commands = []
    for number, line in enumerate(source.splitlines(), start=1):
        command = "".join(line.split("//", 1)[0].split())
        if command:
            commands.append((number, command))
    return commands


def assemble(source):
    """Return a list of 16-bit binary instruction strings."""
    symbols = {f"R{i}": i for i in range(16)}
    symbols.update({
        "SP": 0, "LCL": 1, "ARG": 2, "THIS": 3, "THAT": 4,
        "SCREEN": 16384, "KBD": 24576,
    })
    commands = clean_lines(source)
    instructions = []

    # Pass 1: labels refer to ROM instruction addresses.
    # Labels themselves do not take up an instruction slot.
    for number, command in commands:
        if command.startswith("("):
            if not command.endswith(")") or not valid_symbol(command[1:-1]):
                raise ValueError(f"Line {number}: invalid label {command!r}")
            label = command[1:-1]
            if label in symbols:
                raise ValueError(f"Line {number}: duplicate/reserved label {label!r}")
            if len(instructions) > 32767:
                raise ValueError(f"Line {number}: label address exceeds 32767")
            symbols[label] = len(instructions)
        else:
            instructions.append((number, command))
    if len(instructions) > 32768:
        raise ValueError("Program exceeds the 32768-instruction ROM capacity")

    # Pass 2: resolve symbols and translate the actual instructions.
    next_variable = 16
    binary = []
    for number, command in instructions:
        if command.startswith("@"):
            operand = command[1:]
            if re.fullmatch(r"[0-9]+", operand):
                address = int(operand)
            else:
                if not valid_symbol(operand):
                    raise ValueError(f"Line {number}: invalid symbol {operand!r}")
                if operand not in symbols:
                    if next_variable >= 16384:
                        raise ValueError("Variable memory exhausted")
                    symbols[operand] = next_variable
                    next_variable += 1
                address = symbols[operand]
            if not 0 <= address <= 32767:
                raise ValueError(f"Line {number}: address must be 0 through 32767")
            # A-instruction: leading zero followed by a 15-bit address.
            binary.append(f"{address:016b}")
        else:
            # C-instruction: dest=comp;jump (dest and jump are optional).
            dest = ""
            jump = ""
            comp = command
            if "=" in comp:
                dest, comp = comp.split("=", 1)
                if not dest:
                    raise ValueError(f"Line {number}: missing destination")
            if ";" in comp:
                comp, jump = comp.split(";", 1)
                if not jump:
                    raise ValueError(f"Line {number}: missing jump")
            if dest not in DEST or comp not in COMP or jump not in JUMP:
                raise ValueError(f"Line {number}: invalid C-instruction {command!r}")
            binary.append("111" + COMP[comp] + DEST[dest] + JUMP[jump])
    return binary


def main():
    parser = argparse.ArgumentParser(description="Assemble a Hack .asm file")
    parser.add_argument("file", type=Path, help="Path to the input .asm file")
    args = parser.parse_args()
    input_path = args.file
    if input_path.suffix.lower() != ".asm":
        parser.error("Input must be an .asm file")
    try:
        source = input_path.read_text(encoding="utf-8-sig")
        binary = assemble(source)
        output_path = input_path.with_suffix(".hack")
        output_path.write_text(
            "\n".join(binary) + ("\n" if binary else ""), encoding="ascii"
        )
    except (OSError, UnicodeError, ValueError) as error:
        parser.exit(1, f"Error: {error}\n")
    print(f"Created {output_path} ({len(binary)} instructions)")


if __name__ == "__main__":
    main()
